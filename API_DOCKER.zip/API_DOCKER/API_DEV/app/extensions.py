#Archivo que crea los objetos API y DB para el API y la base de datos respectivamente
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from flask_restplus import Api

api = Api(version='v0.1', title='API DEV', description='API RESTful en Python')

db = SQLAlchemy()
migrate = Migrate()