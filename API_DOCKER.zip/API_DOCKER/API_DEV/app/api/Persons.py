from flask import jsonify
from flask_restplus import Resource, Namespace
from app.extensions import db
from app.model.Persona import Persona
from flask_restplus import fields

person = Namespace('person',description='Operations related to person')

resource_fields = person.model('Person', {
    'id': fields.Integer,
    'name': fields.String(description='The name', required=True),
    'address': fields.String(description='The address', required=True)
})


@person.route('')
class PersonsHandler(Resource):
  @person.response(200, 'Success', resource_fields)
  def get(self):

    person = Persona.query.all()
    return jsonify([h.to_json() for h in person])

  @person.doc(body=resource_fields, validate=True)
  @person.response(200, 'Success', resource_fields)
  def post(self):
    data = self.api.payload
    h = Persona.from_json(data)
    db.session.add(h)
    db.session.commit()
    return jsonify(h.to_json())

  def put(self):
    data = self.api.payload
    person = Persona.query.filter(Persona.id==id).first()
    if not person:
      return self.api.abort(404, "Person id {} doesn't exist".format(id))
    person.name = data.get('name', person.name)
    person.address = data.get('address', person.address)
    db.session.commit()
    return jsonify(person.to_json())


@person.route('/<int:id>')
@person.doc(params={'id': 'An ID'})
class PersonHandler(Resource):
  @person.response(200, 'Success', resource_fields)
  def get(self, id):
    person = Persona.query.filter(Persona.id==id).first()
    if not person:
      return self.api.abort(404, "Person id {} doesn't exist".format(id))
    return jsonify(person.to_json())

  def delete(self, id):
    Persona.query.filter(Persona.id==id).first().delete()
    return jsonify(True)