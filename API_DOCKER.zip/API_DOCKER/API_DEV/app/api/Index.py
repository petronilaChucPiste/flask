from flask_restplus import Resource, Namespace


indice = Namespace('indice')

@indice.route('/')
class PersonasHandler(Resource):

  def get(self):
	  return 'Página del Index'
