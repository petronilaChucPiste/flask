#Este archivo carga algunos parámetros de configuración, en nuestro ejemplo los sacaremos del archivo “.env” 
#que guarda la información inherente al puerto, versión, nombre del proyecto, credenciales de la base de datos, entre otros.
# Standard lib imports
import os
from datetime import timedelta
# Third-party imports
from dotenv import load_dotenv
# BITSON imports

# Ruta base del proyecto
BASEDIR = os.path.dirname(os.path.abspath(__file__))

#ruta del archivo de variables de entorno ".env"
ENV_VARS = os.path.join(BASEDIR, ".env")
#se cargan las variables de entorno
load_dotenv(ENV_VARS)

class BaseConfig: 
    DEBUG = os.environ['DEBUG']
    DB_NAME = os.environ['DB_NAME']
    DB_USER = os.environ['DB_USER']
    DB_PASS = os.environ['DB_PASS']
    DB_SERVICE = os.environ['DB_SERVICE']
    DB_PORT = os.environ['DB_PORT']
    SQLALCHEMY_DATABASE_URI = 'mysql://{0}:{1}@{2}:{3}/{4}'.format(
        DB_USER, DB_PASS, DB_SERVICE, DB_PORT, DB_NAME
    )

    LOG_IN_DB = {
    'OPTIONS': [],
    'GET': [],
    'POST': [201, 200, 400],
    'PUT': [200, 400],
    'DELETE': [204, 400]
    }

    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SLOW_QUERY_TIMEOUT = 0.5
    SQLALCHEMY_RECORD_QUERIES = False

    WTF_CSRF_ENABLED = False

    @staticmethod
    def init_app(app):
        pass