#!/bin/sh
source venv/bin/activate
flask db upgrade
flask translate compile
exec gunicorn -b :9001 --access-logfile - --error-logfile - api_dev:app