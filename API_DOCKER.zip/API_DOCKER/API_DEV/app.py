 #Este archivo es el encargado de iniciar la aplicación, es la semilla que inicia las llamadas a otros archivos de configuración de manera que todo quede andando.
#! /usr/bin/env python

import os
from flask_migrate import MigrateCommand
from flask_script import Manager, Server
from app.backend import create_api
from app.model.Persona import Persona

#Creacion del API con un metodo externo traido del archivo backend

app = create_api(os.getenv('FLASK_CONFIG') or 'default')

#La aplicación esta ejecutandose, se incluye algun comando util.

if __name__ == '__main__':
    manager = Manager(app)
    manager.add_command('db', MigrateCommand)
    manager.add_command("runserver", Server(threaded=bool(int(os.environ.get('THREADED'))), port=int(os.environ.get('PORT'))))
    manager.run(default_command='runserver')