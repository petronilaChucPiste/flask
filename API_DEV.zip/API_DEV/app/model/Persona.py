from sqlalchemy import Integer, String
from app.extensions import db

class Persona(db.Model):
  __tablename__ = 'Persona'
  id = db.Column(Integer, primary_key=True)
  name = db.Column(String(100), nullable=False)
  address = db.Column(String(100), nullable=False)

  def __init__(self, name, address):
    self.name = name
    self.address = address

  @staticmethod
  def from_json(json):
            h = Persona(
                  name=json.get('name'),
                  address=json.get('address')
            )

            return h

  def to_json(self):
            return {
                  'id': self.id,
                  'name': self.name,
                  'address': self.address
            }