#En este archivo es posible crear algunas funciones que inician el API, 
# Abstrayendo al archivo app.py de estas operaciones, que aunque básicas se necesita una lógica especifica.
from flask import Flask
from flask_cors import CORS
from app.extensions import api, db, migrate
from config import BaseConfig
from app.api.Persons import person
from app.api.Index import indice
NAMESPACES = [
    	person,
    	indice
]

def create_api(environment_name=None):
	app = Flask(__name__)
	app.config.from_object(BaseConfig)
	
	for namespace in NAMESPACES:
		api.add_namespace(namespace)

	CORS(app)

	with app.app_context():
		migrate.init_app(app, db)
		db.init_app(app)
	api.init_app(app)
	return app